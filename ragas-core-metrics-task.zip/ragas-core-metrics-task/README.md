# Task: test the 4 core RAGAS metrics

## Background

RAG (Retrieval-Augmented Generation) systems can fail in ways a normal
"did it crash" test can't catch - the pipeline runs fine and still gives
a wrong, irrelevant, or unsupported answer. RAGAS is a popular way to
score RAG quality along four core dimensions. In this task you'll write
the pytest tests that validate those four metrics against a real,
working RAG pipeline - using an LLM as a judge, not string matching.

## What you're given

**`rag.py`** - a minimal, working RAG pipeline against Azure OpenAI:
- `load_chunks()` - splits `knowledge.txt` into paragraph chunks
- `embed_text()` / `cosine_similarity()` / `retrieve_top_chunk()` - retrieval
- `answer_question(query)` - runs the full pipeline, returns `(context, answer)`

**`metrics.py`** - four metric-scoring functions, each using an LLM as a
judge. The judge is asked for one short sentence of reasoning, then a
`SCORE: <a number between 0 and 1>` line, which gets parsed into a float.
This two-step prompt (reasoning before score) matters: a judge asked for
a bare number tends to just say 1.0 for everything.

| Function | Question it answers |
|---|---|
| `faithfulness_score(answer, context, client, judge_model)` | Is the answer actually supported by the retrieved context, or did the model make something up? |
| `answer_relevancy_score(answer, question, client, judge_model)` | Does the answer address the question that was asked? |
| `context_precision_score(context, question, client, judge_model)` | Is the retrieved context actually relevant to the question? |
| `context_recall_score(context, reference_answer, client, judge_model)` | Does the retrieved context contain what's needed to produce a known-good reference answer? |

**`knowledge.txt`** - a short explainer on RAG itself, split into
paragraphs by blank lines. This is the pipeline's only knowledge source.

**`test_metrics.py`** - a skeleton. Fixtures are wired up; the test
bodies are `raise NotImplementedError` placeholders for you to replace.

## What you need to build

### Part 1 - baseline tests (required)

Write four test functions - `test_faithfulness`, `test_answer_relevancy`,
`test_context_precision`, `test_context_recall` - each of which:

1. Gets `(context, answer)` from the `rag_result` fixture (it's already
   run the real pipeline once on `QUESTION = "What is RAG?"`)
2. Calls the matching metric function
3. Prints the score (so it's visible when you run with `-s`)
4. Asserts the score is above `SCORE_THRESHOLD`

### Part 2 - discrimination tests (required)

A judge that scores everything 1.0 isn't actually testing anything - it
needs to be shown it can say no. Write two more tests:

- **A question the knowledge base can't really answer.** `knowledge.txt`
  never explains, say, exactly how a vector database indexes embeddings
  internally. Ask that question, run it through the real pipeline, and
  assert `context_recall_score` (or `context_precision_score`) comes out
  LOW. If it doesn't, either your question wasn't hard enough, or the
  metric has a problem.
- **A deliberately wrong answer.** Write an answer with a specific,
  checkable fact that `knowledge.txt` does not support (an invented
  date, a made-up number, anything a human could point at and say "that's
  not in the text"). Feed it to `faithfulness_score` against a real
  context chunk and assert the score comes out LOW.

## Setup

```
pip install openai python-dotenv pytest
```

Fill in `.env` with your Azure OpenAI endpoint, key, and your chat and
embedding deployment names. `AZURE_OPENAI_JUDGE_DEPLOYMENT` is optional -
leave it blank to use the same model as the chat deployment, or point it
at a different deployment to see how judge choice changes scoring.

Run as you build:
```
pytest test_metrics.py -v -s
```

## Grading checklist

- [ ] 4 baseline tests, one per metric, passing against the real pipeline
- [ ] The pipeline is called once per question, not once per test (use the fixture, don't call `answer_question` again inside a test)
- [ ] At least 2 discrimination tests, each proving a metric can score LOW on a genuinely bad case
- [ ] `SCORE_THRESHOLD` is used, not a magic number repeated five times
- [ ] Every test prints the score it got, so a reviewer can see *why* it passed or failed, not just that it did
- [ ] No `unittest.mock` / no mocking - every test is a real call

## Questions to think about while you work (come prepared to discuss)

1. You ran `test_faithfulness` once and it passed. Does that mean
   `faithfulness_score` is a reliable metric? What would make you trust
   it more or less?
2. If you swap `AZURE_OPENAI_JUDGE_DEPLOYMENT` to a different model and
   all four scores jump to exactly 1.00, is that proof the new answer
   is perfect, or could it mean something else?
3. `context_precision` and `context_recall` sound similar. Write, in
   your own words, a case where a context chunk could score high on one
   and low on the other.
4. Right now the judge sees the whole context as one block. What would
   change if the retrieved context were 5 chunks instead of 1, and you
   wanted to know *which* chunks were actually useful?
