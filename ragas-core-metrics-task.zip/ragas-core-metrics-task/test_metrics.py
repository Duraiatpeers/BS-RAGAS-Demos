"""
TASK: write pytest tests that validate the 4 core RAGAS-style metrics in
metrics.py, by running them against the REAL RAG pipeline in rag.py (no
mocking - every test should make a real call to Azure OpenAI).

The fixtures below are already wired up for you. Replace each
`raise NotImplementedError` with a real test. See README.md for the full
task description, the metric definitions, and the grading checklist.

Run as you go:
    pytest test_metrics.py -v -s
"""

import os

import pytest

from rag import get_client, answer_question, load_chunks
from metrics import (
    faithfulness_score,
    answer_relevancy_score,
    context_precision_score,
    context_recall_score,
)

QUESTION = "What is RAG?"
REFERENCE_ANSWER = (
    "RAG combines retrieving relevant text from a knowledge source with a "
    "language model, so the model can generate an answer grounded in that text."
)
SCORE_THRESHOLD = 0.5


@pytest.fixture(scope="module")
def client():
    return get_client()


@pytest.fixture(scope="module")
def judge_deployment():
    """The model that grades each metric. AZURE_OPENAI_JUDGE_DEPLOYMENT is
    optional in .env - if you leave it blank, this falls back to the same
    model that generated the answer."""
    return os.environ.get("AZURE_OPENAI_JUDGE_DEPLOYMENT") or os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT"]


@pytest.fixture(scope="module")
def rag_result():
    """Runs the real RAG pipeline once for QUESTION, and shares the result
    across all four Part 1 tests below, instead of each test re-running
    the whole pipeline from scratch."""
    context, answer = answer_question(QUESTION)
    return context, answer


# ---------------------------------------------------------------------------
# Part 1 - baseline tests (required)
#
# Each function below should: unpack `rag_result` into (context, answer),
# call the matching metric function from metrics.py, print the score so
# it's visible with -s, and assert it's above SCORE_THRESHOLD.
# ---------------------------------------------------------------------------

def test_faithfulness(rag_result, client, judge_deployment):
    """Is the generated answer actually supported by the retrieved context?"""
    # TODO: call faithfulness_score(...) and assert score > SCORE_THRESHOLD
    raise NotImplementedError


def test_answer_relevancy(rag_result, client, judge_deployment):
    """Does the generated answer address the question that was asked?"""
    # TODO: call answer_relevancy_score(...) and assert score > SCORE_THRESHOLD
    raise NotImplementedError


def test_context_precision(rag_result, client, judge_deployment):
    """Is the retrieved context actually relevant to the question?"""
    # TODO: call context_precision_score(...) and assert score > SCORE_THRESHOLD
    raise NotImplementedError


def test_context_recall(rag_result, client, judge_deployment):
    """Does the retrieved context contain what's needed to produce REFERENCE_ANSWER?"""
    # TODO: call context_recall_score(...) and assert score > SCORE_THRESHOLD
    raise NotImplementedError


# ---------------------------------------------------------------------------
# Part 2 - discrimination tests (required)
#
# A judge that always says "great answer!" isn't testing anything. Prove
# each judge can say no, too. Write your own question/answer pairs - see
# README.md Part 2 for the idea and a hint on where to look in knowledge.txt.
# ---------------------------------------------------------------------------

def test_context_recall_on_a_question_the_knowledge_base_cant_answer_well(client, judge_deployment):
    """Pick a question knowledge.txt doesn't really cover, run the real
    pipeline on it, and show context_recall_score (or context_precision_score)
    comes out LOW - proving the judge isn't just agreeing with everything."""
    # TODO: write HARDER_QUESTION and HARDER_REFERENCE_ANSWER, call
    # answer_question(HARDER_QUESTION), score it, assert score < SCORE_THRESHOLD
    raise NotImplementedError


def test_faithfulness_catches_a_fabricated_answer(client, judge_deployment):
    """Hand faithfulness_score a real context chunk (try load_chunks()[0])
    and a deliberately wrong answer you write yourself - one with a claim
    the context does NOT support - and show the score comes out LOW."""
    # TODO: write FABRICATED_ANSWER yourself, call faithfulness_score(...),
    # assert score < SCORE_THRESHOLD
    raise NotImplementedError
